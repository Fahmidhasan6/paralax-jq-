# xsParallax.js
A simple parallax scrolling jQuery plugin

## Demo
http://rawgit.com/hoangvuit/xsParallax.js/master/demo/demo.html
